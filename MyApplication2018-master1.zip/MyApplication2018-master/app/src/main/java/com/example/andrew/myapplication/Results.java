package com.example.andrew.myapplication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class Results extends AppCompatActivity {

        private FirebaseDatabase database;
        private DatabaseReference myRef;
        DataStructure mData;

        private TextView x;
        private TextView y;
        private TextView xax;
        private TextView yax;
        private TextView cbt;
        private TextView zbt;
        private TextView timestamp;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_results);


            getDatabase();
            findAllViews();
            reterieveData();
        }

    public void clickHome1(View view) {
        Intent intent = new Intent(Results.this, Home.class);
        startActivity(intent);
    }

        private void findAllViews(){
            x = findViewById(R.id.readx);
            y= findViewById(R.id.ready);
            xax = findViewById(R.id.readxax);
            yax = findViewById(R.id.readyax);
            zbt = findViewById(R.id.readzbt);
            cbt = findViewById(R.id.readcbt);
            timestamp = findViewById(R.id.readtimestamp);
        }

        private void getDatabase(){
            // TODO: Find the refernce form the database.
            database = FirebaseDatabase.getInstance();
            myRef = database.getReference("data");
        }

        private void reterieveData(){
            // TODO: Get the data on a single node.
            myRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    DataStructure ds = dataSnapshot.getValue(DataStructure.class);
                    x.setText("X Value: "+ ds.getX());
                    y.setText("Y Value: "+ds.getY());
                    xax.setText("X Axis Value: "+ ds.getXax());
                    yax.setText("Y Axis Value: "+ ds.getYax());
                    cbt.setText("C Button: "+ ds.getCbt());
                    zbt.setText("Z Button: "+ ds.getZbt());
                    // Convert from timestamp to Date and time
                    timestamp.setText(convertTimestamp(ds.getTimestamp()));
                }

                private String convertTimestamp(String timestamp){

                    long yourSeconds = Long.valueOf(timestamp);
                    Date mDate = new Date(yourSeconds * 1000);
                    DateFormat df = new SimpleDateFormat("dd MMM yyyy hh:mm:ss");
                    return df.format(mDate);
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    DataStructure ds = dataSnapshot.getValue(DataStructure.class);
                    x.setText("X Value: "+ ds.getX());
                    y.setText("Y Value: "+ds.getY());
                    xax.setText("X Axis Value: "+ ds.getXax());
                    yax.setText("Y Axis Value: "+ ds.getYax());
                    cbt.setText("C Button: "+ ds.getCbt());
                    zbt.setText("Z Button: "+ ds.getZbt());

                    // Convert from timestamp to Date and time
                    timestamp.setText(convertTimestamp(ds.getTimestamp()));
                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            // TODO: Get the whole data array on a reference.
            myRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    List<DataStructure> arraylist= new ArrayList<DataStructure>();

                    // TODO: Now data is reteieved, needs to process data.
                    if (dataSnapshot != null && dataSnapshot.getValue() != null) {

                        // iterate all the items in the dataSnapshot
                        for (DataSnapshot a : dataSnapshot.getChildren()) {
                            DataStructure dataStructure = new DataStructure();
                            dataStructure.setX(a.getValue(DataStructure.class).getX());
                            dataStructure.setY(a.getValue(DataStructure.class).getY());
                            dataStructure.setXax(a.getValue(DataStructure.class).getXax());
                            dataStructure.setYax(a.getValue(DataStructure.class).getYax());
                            dataStructure.setCbt(a.getValue(DataStructure.class).getCbt());
                            dataStructure.setZbt(a.getValue(DataStructure.class).getZbt());
                            dataStructure.setTimestamp(a.getValue(DataStructure.class).getTimestamp());

                            arraylist.add(dataStructure);  // now all the data is in arraylist.
                            Log.d("MapleLeaf", "dataStructure " + dataStructure.getTimestamp());
                        }
                    }

                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Getting data failed, log a message
                    Log.d("MapleLeaf", "Data Loading Cancelled/Failed.", databaseError.toException());
                }
            });
        }



    }

